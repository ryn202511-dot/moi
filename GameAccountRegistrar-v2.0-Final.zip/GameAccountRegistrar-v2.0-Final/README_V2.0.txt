================================================================================
🎮  GAME ACCOUNT REGISTRAR - VIETNAM EDITION V2.0
================================================================================

✅ PHIÊN BẢN MỚI (V2.0) - TÀI KHOẢN 2024-2025

📦 TINH NĂNG CHÍNH:
================================================================================

1. 🎯 NHẬP DỮ LIỆU TRỰC TIẾP
   - Tab "📥 NHẬP TRỰC TIẾP": Nhập tài khoản trực tiếp vào form
   - Thêm/Xóa/Xóa toàn bộ tài khoản trước khi chạy
   - Toggle hiển thị password khi nhập
   - Danh sách quản lý tài khoản trong giao diện

2. 🔗 CẤU HÌNH ĐẠO DIỆN VÀ PROXY
   - Nhập URL đăng ký
   - Cấu hình Proxy (hoặc không dùng)
   - Chế độ Headless (hiện/ẩn trình duyệt)

3. 🏦 NGÂN HÀNG VIỆT NAM
   - 15 ngân hàng: Vietcombank, ACB, Techcombank, VPBank, BIDV, v.v.
   - Tự động lưu ngân hàng vào kết quả
   - Hỗ trợ chọn ngân hàng trong dropdown

4. 📱 OTP MANAGEMENT
   - Toggle "✓ Sử dụng SDT có OTP"
   - Tải file SDT (sdt.txt) tự động
   - Nhập CodeSim API Key (nếu cần)
   - Tự động điền số điện thoại vào form Selenium

5. 📝 FORM PREVIEW
   - Xem trước các trường form cần điền
   - Chỉnh sửa giá trị trực tiếp trên giao diện
   - Cập nhật real-time khi chạy Selenium

6. 🔐 SELENIUM TỰ ĐỘNG
   - Truy cập URL trang đăng ký
   - Tự động điền form: Username, Email, Password, Phone, Bank, v.v.
   - Gửi form và kiểm tra kết quả
   - Lưu tài khoản thành công vào ACC OK.TXT
   - Lưu lỗi vào FAIL.TXT

7. 📊 LOG & THỐNG KÊ
   - Log chi tiết từng bước Selenium (khởi tạo → điền → gửi)
   - Thống kê real-time: Số thành công, thất bại, tiến độ
   - Color-coded logging (xanh=thành công, đỏ=lỗi, vàng=cảnh báo)
   - Progress bar theo dõi tiến độ

================================================================================

🚀 CÁCH CHẠY:
================================================================================

Cách 1: NHẬP TRỰC TIẾP (Khuyến nghị)
------------------------------------
1. Chạy: python advanced_gui_launcher_vn.py
2. Chọn Tab "📥 NHẬP TRỰC TIẾP"
3. Nhập Username, Email, Password
4. Click "➕ THÊM TÀI KHOẢN"
5. Lặp lại bước 3-4 cho các tài khoản khác
6. Quay lại Tab "⚙️ CẤU HÌNH"
7. Nhập URL đăng ký
8. Chọn Ngân hàng Việt Nam
9. Bật/Tắt OTP nếu cần
10. Click "▶ BẮT ĐẦU ĐĂNG KÝ"

Cách 2: TỪ FILE (Như trước)
---------------------------
1. Chuẩn bị file TK REG.TXT (format: username|email|password)
2. Chạy: python advanced_gui_launcher_vn.py
3. Tab "⚙️ CẤU HÌNH"
4. Click "Browse" để chọn file TK REG.TXT
5. Nhập URL
6. Chọn Ngân hàng
7. Click "▶ BẮT ĐẦU ĐĂNG KÝ"

================================================================================

📁 CẤU TRÚC THƯMỤC:
================================================================================

GameAccountRegistrar-v2.0-Final/
├── advanced_gui_launcher_vn.py    (🎯 CHÍNH - GUI Vietnam Edition)
├── advanced_gui_launcher.py       (Advanced GUI version)
├── gui_launcher.py                (Basic GUI version)
├── game_account_registrar.py      (Core Selenium automation)
├── config.py                      (Cấu hình chung)
├── utils.py                       (Helper functions)
├── requirements.txt               (Python packages)
├── build_windows.bat              (Build .EXE trên Windows)
├── build_linux.sh                 (Build executable trên Linux)
├── WINDOWS_SETUP.bat              (Setup nhanh Windows)
├── sdt.txt                        (Sample phone numbers)
├── TK REG.TXT                     (Sample accounts)
├── README_V2.0.txt                (File này)
├── QUICK_START.txt                (Hướng dẫn nhanh)
├── WINDOWS_FIX.txt                (Fix lỗi Windows)
├── DISTRIBUTION_GUIDE.md          (Guide phân phối)
└── EXE_BUILD_GUIDE.md             (Hướng dẫn build EXE)

================================================================================

⚙️ CÀI ĐẶT:
================================================================================

Yêu cầu:
---------
- Python 3.8+ (được kiểm tra với 3.13)
- Chrome browser (tự động download ChromeDriver)
- Internet connection

Cài đặt trên Windows:
---------------------
1. Mở Command Prompt từ thư mục này
2. Chạy: python -m pip install --upgrade pip
3. Chạy: pip install -r requirements.txt
4. Chạy: python advanced_gui_launcher_vn.py

Cài đặt trên Linux/Mac:
-----------------------
1. Mở Terminal từ thư mục này
2. Chạy: python3 -m pip install --upgrade pip
3. Chạy: pip3 install -r requirements.txt
4. Chạy: python3 advanced_gui_launcher_vn.py

Tạo .EXE (Windows):
-------------------
1. Chạy: build_windows.bat
2. File .EXE sẽ tạo trong thư mục: dist/GameAccountRegistrar.exe

Tạo Executable (Linux/Mac):
----------------------------
1. Chạy: bash build_linux.sh
2. File executable sẽ tạo trong thư mục: dist/GameAccountRegistrar

================================================================================

📝 ĐỊNH DẠNG FILE:
================================================================================

TK REG.TXT (Account Data):
--------------------------
Format: username|email|password
Vd:
user001|user001@gmail.com|Pass123!@#
user002|user002@gmail.com|Pass456$%^
user003|user003@gmail.com|Pass789&*(

sdt.txt (Phone Numbers):
------------------------
Mỗi dòng một số điện thoại
Vd:
0912345678
0909876543
0987654321

================================================================================

📊 KỈT QUẢ:
================================================================================

ACC OK.TXT:
-----------
Lưu các tài khoản đăng ký THÀNH CÔNG
Format: username|email|password|bank|phone

FAIL.TXT:
---------
Lưu các tài khoản THẤT BẠI (kèm lỗi)
Format: original_line|BANK:...|PHONE:...|ERROR:...

================================================================================

🆘 TROUBLESHOOTING:
================================================================================

1. Lỗi: "Vui lòng nhập URL đăng ký"
   → Quên nhập URL. Kiểm tra Tab "⚙️ CẤU HÌNH" > Nhập URL

2. Lỗi: "Vui lòng điền đầy đủ: Username, Email, Password"
   → Nhập trực tiếp nhưng chưa điền đủ 3 trường
   → Kiểm tra Tab "📥 NHẬP TRỰC TIẾP"

3. Lỗi: "Không tìm Username field"
   → CSS selector não đúng cho trang web
   → Thử Tab "📝 FORM ĐĂC KÝ" để chỉnh sửa giá trị

4. Lỗi: "Không xác nhận được thành công"
   → Trang web không hiện success message
   → Xem log để kiểm tra trang web trả về gì

5. Lỗi: ChromeDriver không tìm
   → Chạy: pip install --upgrade webdriver-manager
   → Xóa cache: rm -rf ~/.wdm/

================================================================================

🔗 LIÊN HỆ & HỖ TRỢ:
================================================================================

GitHub: https://github.com/ryn202511-dot/moi
Version: 2.0.0 (Feb 2025)
Status: ✅ Hoạt động ổn định
Python: 3.8 - 3.13

================================================================================

Cảm ơn sử dụng Game Account Registrar! 🙏
================================================================================
